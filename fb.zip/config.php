<?php

require_once('Facebook/autoload.php');

if(!session_id()){
	session_start();
}

$facebook = new Facebook\Facebook([
  'app_id' => '',
  'app_secret' => '',
 // 'default_access_token' => '{access-token}',
  //'enable_beta_mode' => true,
  'default_graph_version' => 'v2.3',
  // 'http_client_handler' => 'guzzle',
  // 'persistent_data_handler' => 'memory',
  // 'url_detection_handler' => new MyUrlDetectionHandler(),
  // 'pseudo_random_string_generator' => new MyPseudoRandomStringGenerator(),
]);
?>