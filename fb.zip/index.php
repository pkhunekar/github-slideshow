<?php
require_once('config.php');
$facebook_output = '';
$facebook_helper = $facebook->getRedirectLoginHelper();
if(isset($_GET['Code'])){
	if(isset($_GET['access_token'])){
		$access_token = $_SESSION['access_token'];
     }
     else{
     	$access_token =$facebook->getRedirectLoginHelper();
     	$_SESSION['access_token'] =	$access_token;
     	$facebook->setDefaultAccessToken($_SESSION['access_token']);
     }
    $graph_response = $facebook->get("me/fields=name,email",$access_token);
    $facebook_user_info = $graph_response->getGraphUser();
    if(!empty($facebook_user_info['id'])){
    	$_SESSION['user_image'] = 'http://grapg.facebook.com/'.$facebook_user_info['id'].'/picture';
    }
    if(!empty($facebook_user_info['name'])){
    	$_SESSION['user_name'] =$facebook_user_info['name'];
    }
     if(!empty($facebook_user_info['email'])){
    	$_SESSION['user_email'] =$facebook_user_info['email'];
    }
}else{
	$facebook_permission = ['email'];
	$facebook_login_url = $facebook_helper->getLoginUrl('localhost/fb',$facebook_permission);
	$facebook_login_url = '<a href="'.$facebook_login_url.'">login.php</a>';
}

if (isset($facebook_login_url)) {
	echo $facebook_login_url;
}else{
	echo '<img src="'.$_SESSION['user_image'].'">';
	echo $_SESSION['user_name'];
	echo $_SESSION['user_email'];
	echo '<a href="logout.php">logout</a>';
}
?>